/* 
 * Copyright 2009-2011 The VOTCA Development Team (http://www.votca.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <boost/lexical_cast.hpp>
#include <votca/tools/rangeparser.h>
#include <votca/csg/beadlist.h>
#include <votca/csg/nblistgrid.h>
#include "csg_stat_imc.h"
#include <votca/csg/imcio.h>

namespace votca { namespace csg {

Imc::Imc()
   : _write_every(0), _do_blocks(false), _do_imc(false), _processed_some_frames(false)
{
}

Imc::~Imc()
{
}

// begin the coarse graining process
// here the data structures are prepared to handle all the data
void Imc::Initialize()
{
    // do some output
    if(_do_imc)
	    cout << "begin to calculate inverse monte carlo parameters\n";
    else
	    cout << "begin to calculate distribution functions\n";
    cout << "# of bonded interactions: " << _bonded.size() << endl;
    cout << "# of non-bonded interactions: " << _nonbonded.size() << endl;

    if ( _bonded.size()+_nonbonded.size() == 0 )
            throw std::runtime_error("No interactions defined in options xml-file - nothing to be done");

    
   // initialize non-bonded structures
   for (list<Property*>::iterator iter = _nonbonded.begin();
            iter != _nonbonded.end(); ++iter) {
        interaction_t *i = AddInteraction(*iter);
        i->_is_bonded = false;
    }

    // initialize non-bonded structures
   for (list<Property*>::iterator iter = _bonded.begin();
        iter != _bonded.end(); ++iter) {
            interaction_t *i = AddInteraction(*iter);
            i->_is_bonded = true;
   }
   
   // initialize the group structures
    if(_do_imc)
        InitializeGroups();
};

void Imc::BeginEvaluate(Topology *top, Topology *top_atom)
{
  // we didn't process any frames so far
    _nframes = 0;
    _nblock = 0;
    _processed_some_frames=false;

    // initialize non-bonded structures
   for (list<Property*>::iterator iter = _nonbonded.begin();
            iter != _nonbonded.end(); ++iter) {
        string name = (*iter)->get("name").value();

        interaction_t &i = *_interactions[name];

        // generate the bead lists
        BeadList beads1, beads2;

        beads1.Generate(*top, (*iter)->get("type1").value());
        beads2.Generate(*top, (*iter)->get("type2").value());

        if(beads1.size() == 0)
            throw std::runtime_error("Topology does not have beads of type \"" + (*iter)->get("type1").value() + "\"\n"
                    "This was specified in type1 of interaction \"" + name+ "\"");
        if(beads2.size() == 0)
            throw std::runtime_error("Topology does not have beads of type \"" + (*iter)->get("type2").value() + "\"\n"
                    "This was specified in type2 of interaction \"" + name + "\"");
        // calculate normalization factor for rdf

        if ((*iter)->get("type1").value() == (*iter)->get("type2").value())
            i._norm = 1. / (beads1.size()*(beads2.size()) / 2.);
        else
            i._norm = 1. / (beads1.size() * beads2.size());
    }
}

// create an entry for interactions
Imc::interaction_t *Imc::AddInteraction(Property *p)
{
    string name = p->get("name").value();
    string group;
    if(_do_imc)
        group = p->get("inverse.imc.group").value();
    else
        group = "none";
    
    interaction_t *i = new interaction_t;
    i->_index = _interactions.size();
    _interactions[name] = i;
    getGroup(group)->_interactions.push_back(i);
    
    i->_step = p->get("step").as<double>();
    i->_min = p->get("min").as<double>();
    i->_max = p->get("max").as<double>();
    i->_norm = 1.0;
    i->_p=p;
    
    // initialize the current and average histogram
    int n = (int)((i->_max - i->_min) / i->_step + 1.000000001);

    i->_average.Initialize(i->_min, i->_max+i->_step, n);
    
    return i;
}

// end of trajectory, post processing data
void Imc::EndEvaluate()
{
    if(_nframes > 0) {
        if(!_do_blocks) {
            WriteDist();
            if(_do_imc)
                WriteIMCData();
        }
    }
    // clear interactions and groups
    _interactions.clear();
    _groups.clear();
    if(!_processed_some_frames)
        throw std::runtime_error("no frames were processed. Please check your input");
}

// load options from xml file
void Imc::LoadOptions(const string &file) {
    load_property_from_xml(_options, file);
    _bonded = _options.Select("cg.bonded");
    _nonbonded = _options.Select("cg.non-bonded");
        
}

// evaluate current conformation
void Imc::Worker::EvalConfiguration(Topology *top, Topology *top_atom) {
    
    _cur_vol = top->BoxVolume();
    // process non-bonded interactions
    DoNonbonded(top);
    // process bonded interactions
    DoBonded(top);            
}

void Imc::ClearAverages()
{
    map<string, interaction_t *>::iterator ic_iter;
    map<string, group_t *>::iterator group_iter;
    
    _nframes = 0;
    for (ic_iter = _interactions.begin(); ic_iter != _interactions.end(); ++ic_iter)
        ic_iter->second->_average.Clear();    
    
    for (group_iter = _groups.begin(); group_iter != _groups.end(); ++group_iter)
        group_iter->second->_corr.clear();      
}

class IMCNBSearchHandler {
public:
    IMCNBSearchHandler(HistogramNew *hist)
            : _hist(hist) {}

    HistogramNew *_hist;

    bool FoundPair(Bead *b1, Bead *b2, const vec &r, const double dist) {
        _hist->Process(dist);
        return false;
    }
};


// process non-bonded interactions for current frame
void Imc::Worker::DoNonbonded(Topology *top)
{
    for (list<Property*>::iterator iter = _imc->_nonbonded.begin();
            iter != _imc->_nonbonded.end(); ++iter) {
        string name = (*iter)->get("name").value();
        
        interaction_t &i = *_imc->_interactions[name];
        
        // generate the bead lists
        BeadList beads1, beads2;
        
        beads1.Generate(*top, (*iter)->get("type1").value());
        beads2.Generate(*top, (*iter)->get("type2").value());
               
        // generate the neighbour list
        NBList *nb;

        bool gridsearch=true;

        if(_imc->_options.exists("cg.nbsearch")) {
            if(_imc->_options.get("cg.nbsearch").as<string>() == "grid")
                gridsearch=true;
            else if(_imc->_options.get("cg.nbsearch").as<string>() == "simple")
                gridsearch=false;
            else throw std::runtime_error("cg.nbsearch invalid, can be grid or simple");
        }
        if(gridsearch)
            nb = new NBListGrid();
        else
            nb = new NBList();

        nb->setCutoff(i._max + i._step);
                
        // clear the current histogram
        _current_hists[i._index].Clear();

        IMCNBSearchHandler h(&(_current_hists[i._index]));

        nb->SetMatchFunction(&h, &IMCNBSearchHandler::FoundPair);

        // is it same types or different types?
        if((*iter)->get("type1").value() == (*iter)->get("type2").value())
            nb->Generate(beads1);
        else
            nb->Generate(beads1, beads2);

        // process all pairs
        /*NBList::iterator pair_iter;
        for(pair_iter = nb->begin(); pair_iter!=nb->end();++pair_iter) {
                _current_hists[i._index].Process((*pair_iter)->dist());
        }*/

        delete nb;
    }    
}

// process non-bonded interactions for current frame
void Imc::Worker::DoBonded(Topology *top)
{
    for (list<Property*>::iterator iter = _imc->_bonded.begin();
            iter != _imc->_bonded.end(); ++iter) {
        string name = (*iter)->get("name").value();
        
        interaction_t &i = *_imc->_interactions[name];

        // clear the current histogram
        _current_hists[i._index].Clear();

        // now fill with new data
        std::list<Interaction *> list = top->InteractionsInGroup(name);

        std::list<Interaction *>::iterator ic_iter;
        for(ic_iter=list.begin(); ic_iter!=list.end(); ++ic_iter) {
            Interaction *ic = *ic_iter;
            double v = ic->EvaluateVar(*top);
            _current_hists[i._index].Process(v);
        }
    }    
}

// returns a group, creates it if doesn't exist
Imc::group_t *Imc::getGroup(const string &name)
{
    map<string, group_t *>::iterator iter;
    iter = _groups.find(name);
    if(iter == _groups.end()) {
        return _groups[name] = new group_t;
    }
    return (*iter).second;
}

// initialize the groups after interactions are added
void Imc::InitializeGroups()
{
    if(!_do_imc) return;
    map<string, group_t *>::iterator group_iter;

    // clear all the pairs
    
    // iterator over all groups
    for (group_iter = _groups.begin(); group_iter != _groups.end(); ++group_iter) {
        group_t *grp = (*group_iter).second;      
        grp->_pairs.clear();
    
        int n = 0;
        // count number of bins needed in matrix
        for (list<interaction_t*>::iterator i1 = grp->_interactions.begin();
                i1 != grp->_interactions.end(); ++i1)
            n+=(*i1)->_average.getNBins();
    
        // handy access to matrix
        group_matrix &M = grp->_corr;
        
        // initialize matrix with zeroes
        M.resize(n,n);
        M = ub::zero_matrix<double>(n, n);
        
        // now create references to the sub matrices
        int i, j;
        i=0;j=0;
        // iterate over all possible compinations of pairs
        for (list<interaction_t*>::iterator i1 = grp->_interactions.begin();
                i1 != grp->_interactions.end(); ++i1) {
            int n1 = (*i1)->_average.getNBins();
            j = i;
            for (list<interaction_t*>::iterator i2 = i1;
                    i2 != grp->_interactions.end(); ++i2) {
                int n2 = (*i2)->_average.getNBins();
                
                // create matrix proxy with sub-matrix
                pair_matrix corr(M, ub::range(i, i+n1), ub::range(j, j+n2));
                // add the pair
                grp->_pairs.push_back(pair_t(*i1, *i2, i, j, corr));
                j+=n2;
            }
            i+=n1;
        }
    }
}

// update the correlation matrix
void Imc::DoCorrelations(Imc::Worker *worker) {
    if(!_do_imc) return;
    vector<pair_t>::iterator pair;
    map<string, group_t *>::iterator group_iter;
        
     for (group_iter = _groups.begin(); group_iter != _groups.end(); ++group_iter) {
        group_t *grp = (*group_iter).second;      
        // update correlation for all pairs
        for (pair = grp->_pairs.begin(); pair != grp->_pairs.end(); ++pair) {
            ub::vector<double> &a = worker->_current_hists[pair->_i1->_index].data().y();
            ub::vector<double> &b = worker->_current_hists[pair->_i2->_index].data().y();
            pair_matrix &M = pair->_corr;

            // M_ij += a_i*b_j
            //for(int i=0; i<M.size1(); ++i)
            //    for(int j=i; j<M.size2(); ++j)
            //        M(i,j) = ((((double)_nframes-1.0)*M(i,j)) + (a(i)*b(j)))/(double)_nframes;
            M = ((((double)_nframes-1.0)*M) + ub::outer_prod(a, b))/(double)_nframes;
        }
    }
}

// write the distribution function
void Imc::WriteDist(const string &suffix)
{
    map<string, interaction_t *>::iterator iter;

    // for all interactions
    for (iter = _interactions.begin(); iter != _interactions.end(); ++iter) {            
        // calculate the rdf
        Table &t = iter->second->_average.data();            
        Table dist(t);
        if(!iter->second->_is_bonded) {
            // normalization is calculated using exact shell volume (difference of spheres)
            for(int i=0; i<dist.y().size(); ++i) {
                double x1 = dist.x()[i] - 0.5*iter->second->_step;
                double x2 = x1 + iter->second->_step;
                if(x1<0) {
                    dist.y()[i]=0;
                }
                else {
                    dist.y()[i] = _avg_vol.getAvg()*iter->second->_norm *
                        dist.y()[i]/(4./3.*M_PI*(x2*x2*x2 - x1*x1*x1));                
                }
            }
        }
        else {
            dist.y() = iter->second->_norm * dist.y();
        }
        
        dist.Save((iter->first) + suffix + ".dist.new");
        cout << "written " << (iter->first) + suffix + ".dist.new\n";            
    }
}


/**
 *  Here the inverse monte carlo matrix is calculated and written out
 *
 *  steps:
 *      - calculate th
 */
void Imc::WriteIMCData(const string &suffix) {            
    if(!_do_imc) return;
    //map<string, interaction_t *>::iterator ic_iter;
    map<string, group_t *>::iterator group_iter;
    
    // iterate over all groups
    for(group_iter = _groups.begin(); group_iter!=_groups.end(); ++group_iter) {
        group_t *grp = (*group_iter).second;    
        string grp_name = (*group_iter).first;
        list<interaction_t *>::iterator iter;
        
        // number of total bins for all interactions in group is matrix dimension
        int n=grp->_corr.size1();
                
        // build full set of equations + copy some data to make
        // code better to read
        group_matrix gmc(grp->_corr);
        ub::vector<double> dS(n);
        ub::vector<double> r(n);
        // the next two variables are to later extract the individual parts
        // from the whole data after solving equations
        vector<RangeParser> ranges; // sizes of the individual interactions
        vector<string> names; // names of the interactions
                        
        // copy all averages+r of group to one vector
        n=0;
        int begin=1;
        for(iter=grp->_interactions.begin(); iter != grp->_interactions.end(); ++iter) {
            interaction_t *ic = *iter;
            
            // sub vector for dS
            ub::vector_range< ub::vector<double> > sub_dS(dS, 
                    ub::range(n, n + ic->_average.getNBins()));
            
            // sub vector for r
            ub::vector_range< ub::vector<double> > sub_r(r, 
                    ub::range(n, n + ic->_average.getNBins()));
            
            // read in target and calculate dS
            CalcDeltaS(ic, sub_dS);
            
            // copy r
            sub_r = ic->_average.data().x();
            
            // save size

            RangeParser rp;
            int end = begin  + ic->_average.getNBins() -1;
            rp.Add(begin, end);
            ranges.push_back(rp);
            begin = end+1;
            // save name
            names.push_back(ic->_p->get("name").as<string>());
            
            // shift subrange by size of current
            n+=ic->_average.getNBins();
        }
        
        // now we need to calculate the 
        // A_ij = <S_i*S_j> - <S_i>*<S_j>        
        vector<pair_t>::iterator pair;
        for (pair = grp->_pairs.begin(); pair != grp->_pairs.end(); ++pair) {
            interaction_t *i1 = pair->_i1;
            interaction_t *i2 = pair->_i2;
            
            // make reference to <S_i>
            ub::vector<double> &a = i1->_average.data().y();
            // make reference to <S_j>
            ub::vector<double> &b = i2->_average.data().y();
            
            int i=pair->_offset_i;
            int j=pair->_offset_j;
            int n1=i1->_average.getNBins();
            int n2=i2->_average.getNBins();
            
            // sub matrix for these two interactions
            // we only need to take care about one sub-matrix and not the mirrored
            // one since ublas makes sure the matrix is symmetric
            pair_matrix M(gmc, ub::range(i, i+n1),
                               ub::range(j, j+n2));
            // A_ij = -(<a_i*a_j>  - <a_i>*<b_j>)
            //for(i=0; i<M.size1(); ++i)
            //    for(j=i; j<M.size2(); ++j)
            //        M(i,j) = -(M(i,j) - a(i)*b(j));
            M = -(M - ub::outer_prod(a, b));
        }
        
        imcio_write_dS(grp_name + suffix + ".imc", r, dS);
        imcio_write_matrix(grp_name + suffix + ".gmc", gmc);
        imcio_write_index(grp_name + suffix + ".idx", names, ranges);

    }
}

// calculate deviation from target vectors
void Imc::CalcDeltaS(interaction_t *interaction, ub::vector_range< ub::vector<double> > &dS)
{
    const string &name = interaction->_p->get("name").as<string>();
                
    Table target;
    target.Load(name + ".dist.tgt");

    if(!interaction->_is_bonded) {
        for(int i=0; i<target.y().size(); ++i) {
            double x1 = target.x()[i] - 0.5*interaction->_step;
            double x2 = x1 + interaction->_step;
            if(x1<0)
                x1=x2=0;
            target.y()[i] = 1./(_avg_vol.getAvg()*interaction->_norm) *
                target.y()[i] * (4./3.*M_PI*(x2*x2*x2 - x1*x1*x1));                
        }        
    }
    else {
            target.y() = (1.0 / interaction->_norm)*target.y();
    }
    if(target.y().size() !=  interaction->_average.data().y().size())
        throw std::runtime_error("number of grid points in target does not match the grid");

    dS = interaction->_average.data().y() - target.y();
}


void Imc::WriteIMCBlock(const string &suffix)
{
    if(!_do_imc) return;
    //map<string, interaction_t *>::iterator ic_iter;
    map<string, group_t *>::iterator group_iter;

    // iterate over all groups
    for(group_iter = _groups.begin(); group_iter!=_groups.end(); ++group_iter) {
        group_t *grp = (*group_iter).second;
        string grp_name = (*group_iter).first;
        list<interaction_t *>::iterator iter;

        // number of total bins for all interactions in group is matrix dimension
        int n=grp->_corr.size1();

        // build full set of equations + copy some data to make
        // code better to read
        group_matrix gmc(grp->_corr);
        ub::vector<double> dS(n);
        ub::vector<double> r(n);
        // the next two variables are to later extract the individual parts
        // from the whole data after solving equations
        vector<int> sizes; // sizes of the individual interactions
        vector<string> names; // names of the interactions

        // copy all averages+r of group to one vector
        n=0;
        for(iter=grp->_interactions.begin(); iter != grp->_interactions.end(); ++iter) {
            interaction_t *ic = *iter;

            // sub vector for dS
            ub::vector_range< ub::vector<double> > sub_dS(dS,
                    ub::range(n, n + ic->_average.getNBins()));

            // sub vector for r
            ub::vector_range< ub::vector<double> > sub_r(r,
                    ub::range(n, n + ic->_average.getNBins()));

            // read in target and calculate dS
            sub_dS = ic->_average.data().y();
            // copy r
            sub_r = ic->_average.data().x();
            // save size
            sizes.push_back(ic->_average.getNBins());
            // save name
            names.push_back(ic->_p->get("name").as<string>());

            // shift subrange by size of current
            n+=ic->_average.getNBins();
        }

        // write the dS
        ofstream out_dS;
        string name_dS = grp_name + suffix + ".S";
        out_dS.open(name_dS.c_str());
        out_dS << setprecision(8);
        if(!out_dS)
            throw runtime_error(string("error, cannot open file ") + name_dS);

        for(size_t i=0; i<dS.size(); ++i) {
            out_dS << r[i] << " " << dS[i] << endl;
        }

        out_dS.close();
        cout << "written " << name_dS << endl;

        // write the correlations
        ofstream out_cor;
        string name_cor = grp_name + suffix + ".cor";
        out_cor.open(name_cor.c_str());
        out_cor << setprecision(8);

        if(!out_cor)
            throw runtime_error(string("error, cannot open file ") + name_cor);

        for(group_matrix::size_type i=0; i<grp->_corr.size1(); ++i) {
            for(group_matrix::size_type j=0; j<grp->_corr.size2(); ++j) {
                out_cor << grp->_corr(i, j) << " ";
            }
            out_cor << endl;
        }
        out_cor.close();
        cout << "written " << name_cor << endl;
    }
}

CsgApplication::Worker *Imc::ForkWorker()
{
    Imc::Worker *worker;
    worker = new Imc::Worker;
    map<string, interaction_t *>::iterator ic_iter;

    worker->_current_hists.resize(_interactions.size());
    worker->_imc = this;

    for (ic_iter = _interactions.begin(); ic_iter != _interactions.end(); ++ic_iter) {
        interaction_t *i = ic_iter->second;
        worker->_current_hists[i->_index].Initialize(
        i->_average.getMin(),
        i->_average.getMax(),
        i->_average.getNBins());
    }
    return worker;
}

void Imc::MergeWorker(CsgApplication::Worker* worker_)
{
    _processed_some_frames = true;
    Imc::Worker *worker = dynamic_cast<Imc::Worker *>(worker_);
        // update the average
    map<string, interaction_t *>::iterator ic_iter;
    //map<string, group_t *>::iterator group_iter;

    ++_nframes;
    _avg_vol.Process(worker->_cur_vol);
    for (ic_iter = _interactions.begin(); ic_iter != _interactions.end(); ++ic_iter) {
        interaction_t *i=ic_iter->second;
        i->_average.data().y() = (((double)_nframes-1.0)*i->_average.data().y()
            + worker->_current_hists[i->_index].data().y())/(double)_nframes;
    }

        // update correlation matrices
    if(_do_imc)
        DoCorrelations(worker);

    if(_write_every != 0) {
        if((_nframes % _write_every)==0) {
            _nblock++;
            string suffix = string("_") + boost::lexical_cast<string>(_nblock);
            WriteDist(suffix);
            WriteIMCData(suffix);
            WriteIMCBlock(suffix);
            if(_do_blocks)
                ClearAverages();
        }
    }

}

}}
