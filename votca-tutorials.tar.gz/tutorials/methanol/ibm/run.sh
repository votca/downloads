#!/bin/bash

echo 'running csg_inverse "settings.xml"'
csg_inverse settings.xml

