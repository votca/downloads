#! /bin/bash

grompp -v

mdrun -v

