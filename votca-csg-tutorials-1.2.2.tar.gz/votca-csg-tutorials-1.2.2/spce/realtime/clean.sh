rm -f CG-CG.dpot.new CG-CG.pot.new CG-CG.dist.new
rm -rf step_*
rm -f inverse.log
rm -f convergence.dat
rm -f *~
rm -rf CG-CG.dist.tgt
