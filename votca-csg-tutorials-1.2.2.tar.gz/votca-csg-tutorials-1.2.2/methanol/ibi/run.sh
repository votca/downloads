#!/bin/bash

echo 'running csg_inverse --options "settings.xml"'
csg_inverse --options settings.xml

