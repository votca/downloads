#!/bin/bash -e

echo 'running csg_inverse --options "settings.xml"'
csg_inverse --options settings.xml

