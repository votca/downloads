#!/bin/bash

csg_inverse --options settings.xml
