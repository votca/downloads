#! /bin/bash -e

echo "Start IBI"

csg_inverse --options settings_IBI.xml
rm done

echo "Finished run"
# end of run file

