#! /bin/bash -e

grompp -v

mdrun -v

